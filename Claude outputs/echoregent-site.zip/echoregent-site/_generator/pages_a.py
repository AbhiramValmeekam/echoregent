from lib import *

def cell(inner, cls=""): return f'<div class="cell {cls}">{inner}</div>'

# ---------------------------------------------------------------- HOME
def home():
    hero = f'''<section class="sec grid hero"><div class="wrap">
<p class="eyebrow"><span class="dot"></span>Context Management for LLMs</p>
<div class="brand-xl">{BRAND.upper()}<small>context</small></div>
<h1>Stop paying for tokens<br><em>you don't need.</em></h1>
<div class="rule"></div>
<p class="desc">Drop-in context management for GPT-4o, Claude, Gemini, and any OpenAI-compatible model. Compress, cache, and protect every conversation — one API call.</p>
<div class="actions">{btn("Get Started Free →","/pricing#get-key")}{btn("See the Benchmark →","/research","btn-ghost")}</div>
<div class="hero-stats">
 <div><div class="stat-n" data-target="26" data-suffix="x">26x</div><div class="eyebrow stat-l">Token efficiency vs mem0</div></div>
 <div><div class="stat-n" data-target="65" data-suffix="%">65%</div><div class="eyebrow stat-l">Avg token reduction</div></div>
 <div><div class="stat-n">&lt;10ms</div><div class="eyebrow stat-l">Per-turn overhead</div></div>
 <div><div class="stat-n" data-target="14" data-prefix="F1 +" data-suffix="%">F1 +14%</div><div class="eyebrow stat-l">Quality vs full context</div></div>
</div></div></section>'''
    sq = '<svg viewBox="0 0 26 26" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="3" y="3" width="20" height="20"/><path d="M3 3l20 20"/></svg>'
    one = "".join(f"<div>{sq}{n}</div>" for n in ["Google for Startups","NVIDIA Inception","T-Hub Hyderabad","Microsoft for Startups"])
    logos = f'<section class="logos" aria-label="Backed and supported by"><p class="eyebrow">Backed &amp; supported by</p><div class="marq">{one*2}</div></section>'

    pg = sec("gray", f'''<div class="reveal">{eyebrow("01","Interactive Playground")}
<h2 class="t-sec m">See it compress<br>in real-time.</h2>
<p class="lead">Select a conversation type, hit compress, and watch our context pipeline classify and compress the text.</p></div>
<div class="mt reveal"><div class="tabs" role="tablist"><button class="tab" role="tab" data-i="0">Developer Logs</button><button class="tab" role="tab" data-i="1">Customer Support</button><button class="tab" role="tab" data-i="2">Medical Query</button></div>
<div class="pg"><div><span class="eyebrow">Input</span><textarea id="demo-input" aria-label="Conversation input"></textarea>
<button class="btn" id="demo-run" type="button">Compress &amp; Classify →</button></div>
<div><div class="pg-head"><span class="eyebrow">Pipeline Output</span><span class="badge" id="demo-badge">IDLE</span></div>
<div class="out" id="demo-out">Press 'Compress &amp; Classify' to start the pipeline...</div>
<div class="metrics"><div><span class="eyebrow">Domain</span><b id="m-domain">—</b></div><div><span class="eyebrow">Intent</span><b id="m-intent">—</b></div><div><span class="eyebrow">Risk Level</span><b id="m-risk">—</b></div><div><span class="eyebrow">Token Savings</span><b id="m-savings">—</b></div></div></div></div></div>''', "playground")

    pipe = [("Incoming","message + history"),("Classifier","intent · domain · risk"),("Compressor","65% reduction avg"),("Cache","semantic · <5ms"),("Your LLM","clean, compressed context")]
    arch = sec("navy", f'''<div class="reveal">{eyebrow("02","Architecture")}<h2 class="t-sec m">Every turn. Classified.<br>Compressed. Protected.</h2>
<p class="lead">Purpose-built context pipeline. No extra LLM calls. No data shared with third parties.</p></div>
<div class="pipe reveal">''' + "".join(f'<div><div class="k">{a}</div><div class="d">{e(b)}</div></div>' for a, b in pipe) + "</div>", "architecture")

    feats = [("Classify","Domain &amp; Intent Detection","Fine-tuned classifier across 10 domains — coding, medical, legal, sales, customer support, and more. Returns domain, intent, risk level, and emotional state per turn. No LLM call.","&lt;10ms","per classification"),
     ("Compress","History Compression","Removes noise while preserving semantic meaning. Stack traces compress well. Medical history doesn't — by design. Compression is domain-aware, not uniform. Measured on LoCoMo: 259 tokens vs 18,679 for full context.","64.7%","avg token reduction"),
     ("Cache","Semantic Similarity Cache","Catches semantically equivalent questions before they reach the compressor. Returning users skip reprocessing entirely. Savings compound with usage.","Sub-5ms","cache lookup per turn"),
     ("Protect","Protected Zones","Medical, legal, and crisis conversations are never compressed. Not a filter — an architectural boundary. If the classifier returns medical, compression is disabled at the function level.","Hard floor","no compression · no leakage")]
    fc = "".join(f'<div class="cell feat"><div class="tagrow"><span class="tag">{a}</span><span class="num">0{i+1}</span></div><h3 class="t-card mt-s" style="margin-top:22px">{b}</h3><p>{c}</p><div class="big">{d}</div><div class="big-l">{f}</div></div>' for i, (a, b, c, d, f) in enumerate(feats))
    features = sec("white", f'''<div class="reveal">{eyebrow("03","Features")}<h2 class="t-sec m">Infrastructure that<br>remembers what counts.</h2>
<p class="lead">Four systems in one API. Each one invisible to your LLM. Each one critical to your bill.</p></div><div class="grid2 mt reveal">{fc}</div>''', "features")

    bm = sec("teal", f'''<div class="reveal">{eyebrow("04","Benchmark · LoCoMo")}<h2 class="t-sec m">26x fewer tokens.<br>Better quality.</h2>
<p class="lead">Measured on LoCoMo — the same benchmark mem0 uses in their published results. Same dataset. Different architecture.</p></div>
<div class="mt reveal">{table(["Approach","Memory Tokens","Quality (F1)","On-device","Protected Zones"],[[BRAND,"259","0.079 +14%","Yes","Yes"],["mem0","6,956","N/A*","—","—"],["Full context (baseline)","~18,679","0.069","—","—"]],hl=0)}
<p class="note">* mem0 quality reported via LLM-as-judge (different scale). {BRAND} F1 uses token-overlap on LoCoMo QA pairs. mem0's 6,956 figure is their own published number.</p>
<div class="mt-s">{btn("Full methodology →","/research")}</div></div>''', "benchmark")

    integ = sec("white", f'''<div class="split"><div class="reveal">{eyebrow("05","Integration")}<h2 class="t-sec m">One line.<br>Any model.</h2>
<p class="lead">Drop-in OpenAI-compatible proxy. Change your baseURL — nothing else. Works with GPT-4o, Claude, Gemini, or any OpenAI-compatible endpoint.</p>
<div class="mt-s" style="margin-top:28px">{btn("Integration Docs →","/docs")}</div>
<p class="eyebrow" style="margin-top:44px">Also works natively with:</p>
<div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:14px"><span class="tag">Claude Desktop</span><span class="tag">Cursor</span><span class="tag">Windsurf</span><span class="tag">Any MCP client</span></div></div>
<div class="reveal"><p class="eyebrow">Before</p>{code("""const openai = new OpenAI({
  apiKey: "sk-..."
})""","JavaScript")}
<p class="eyebrow" style="margin-top:28px">With {BRAND} — 3 lines added</p>{code(f"""const openai = new OpenAI({{
  apiKey: "sk-...",
  baseURL: "https://api.{BRAND}.ai/v1",
  defaultHeaders: {{
    "x-cts-key": "your-echoregent-key"
  }}
}})
// Every call is now classified, compressed,
// cached, and protected automatically.""","JavaScript")}</div></div>''', "integration")

    plans = f'''<div class="plans mt reveal">
<div class="plan"><span class="eyebrow">Free</span><div class="price">$0</div><div class="per">forever</div><ul><li>10M tokens / month</li><li>All 10 domains</li><li>Protected zones</li><li>MCP server</li></ul>{btn("Get API Key","/pricing#get-key","btn")}</div>
<div class="plan pop"><span class="pop-b">Popular</span><span class="eyebrow">Starter</span><div class="price">$199</div><div class="per">per month</div><ul><li>50M tokens / month</li><li>All 10 domains</li><li>Protected zones</li><li>Email support</li></ul>{btn("Start","/pricing#get-key","btn-coral")}</div>
<div class="plan"><span class="eyebrow">Pro</span><div class="price">$499</div><div class="per">per month</div><ul><li>250M tokens / month</li><li>All 10 domains</li><li>Protected zones</li><li>Priority support</li></ul>{btn("Start","/pricing#get-key","btn-ghost")}</div>
<div class="plan"><span class="eyebrow">Agency</span><div class="price">$999</div><div class="per">per month</div><ul><li>Unlimited tokens</li><li>All 10 domains</li><li>Protected zones</li><li>Dedicated support</li></ul>{btn("Contact Us","/enterprise","btn-ghost")}</div></div>'''
    pricing = sec("gray", f'''<div class="reveal">{eyebrow("06","Pricing")}<h2 class="t-sec m">Start free.<br>Scale when you grow.</h2>
<p class="lead">10M tokens free every month. No credit card. API key in under 60 seconds.</p></div>{plans}<div class="mt-s" style="margin-top:36px">{btn("See full pricing →","/pricing","btn-ghost")}</div>''', "pricing")

    cta = sec("coral", f'''<div class="reveal" style="max-width:56rem">{eyebrow("07","Get started")}<h2 class="t-sec">Ready to cut your token bill?</h2>
<p class="lead">One API call. Every conversation classified, compressed, cached, and protected.</p>
<div class="page-hero"><div class="actions">{btn("Get API Key — Free","/pricing#get-key")}{btn("Read the Docs","/docs","btn-ghost")}</div></div></div>''')
    page("/", f"{BRAND} — Stop Paying for Tokens You Don't Need", hero + logos + pg + arch + features + bm + integ + pricing + cta, active="/",
         desc="Drop-in context management for LLMs. 26x more token-efficient than mem0. Compress, cache, and protect every conversation — one API call.",
         og=f"{BRAND} — LLM Context Management")

# ---------------------------------------------------------------- PRODUCT
def product():
    hero = page_hero("Product", "Four systems. / One API.", "Everything runs on CPU in your infrastructure. No GPU, no external embedding calls, no data egress.")
    cls = sec("white", f'''<div class="split"><div class="reveal">{eyebrow("01","Classify")}<h2 class="t-sec m">Context Classifier</h2>
<div class="prose"><p class="lead" style="margin-top:22px">DistilBERT fine-tuned on 10 conversation domains. Runs entirely on CPU. Returns domain, intent, risk level, and emotional state per turn in under 10ms. No LLM call required.</p>
<p>The classifier is the foundation of everything else — it determines whether to compress, which compression strategy to apply, and whether the conversation is protected.</p></div>
<div class="mt-s" style="margin-top:28px">{checks(["10 domains: coding, medical, legal, sales, support, finance, education, creative, crisis, general","Intent detection (debugging, planning, explaining, etc.)","Risk level 0–3 per turn","&lt;10ms on CPU · no GPU · no external calls"])}</div></div>
<div class="reveal">{code("""{
  "domain": "coding",
  "intent": "debugging",
  "riskLevel": 0,
  "state": "frustrated",
  "protected": false
}""","Response — /compress")}<div class="stats" style="grid-template-columns:1fr"><div><div class="stat-n">&lt;10ms</div><div class="eyebrow stat-l">per classification on CPU</div></div></div></div></div>''', "classify")
    comp = sec("navy", f'''<div class="split"><div class="reveal">{eyebrow("02","Compress")}<h2 class="t-sec m">History Compressor</h2>
<p class="lead">T5 removes conversational noise while preserving semantic meaning. Not a truncation — a summarisation. Previous turns get compressed; the current turn is always left untouched.</p>
<p class="lead" style="margin-top:18px">Compression is domain-aware. Medical history doesn't compress. Legal transcripts don't compress. Stack traces compress aggressively. The same model, different strategies per domain.</p>
<div style="margin-top:28px">{checks(["T5 sequence-to-sequence summarisation","Domain-aware strategy selection","Last N turns always preserved uncompressed","64.7% average reduction · 87% quality match"])}</div></div>
<div class="reveal"><div class="grid3" style="grid-template-columns:1fr 1fr"><div class="cell dk"><div class="stat-n" style="color:var(--gray)">18,679</div><div class="eyebrow stat-l">original tokens</div></div><div class="cell dk"><div class="stat-n" style="color:var(--teal)">6,601</div><div class="eyebrow stat-l">compressed tokens</div></div></div>
<div class="big" style="color:var(--coral);font-size:clamp(4rem,9vw,8rem)">64.7%</div><div class="big-l">Average token reduction</div></div></div>''', "compress")
    cache = sec("white", f'''<div class="split"><div class="reveal">{eyebrow("03","Cache")}<h2 class="t-sec m">Semantic Cache</h2>
<p class="lead">MiniLM generates 384-dimensional embeddings for each incoming query. If a semantically equivalent query has been processed before, the cached compressed context is returned — skipping compression entirely.</p>
<p class="lead" style="margin-top:18px">Works across users: if two different users ask semantically similar questions in the same session type, the second user benefits from the first user's compression. Cache savings compound over time.</p></div>
<div class="reveal">{checks(["MiniLM embeddings · 384 dimensions","Cosine similarity threshold (configurable)","Sub-5ms cache lookup before compression","Cache hit returned as <code>x-cts-cache-hit: true</code>"])}
<div class="stats" style="grid-template-columns:1fr"><div><div class="stat-n">Sub-5ms</div><div class="eyebrow stat-l">cache lookup per turn</div></div></div>
<p class="note">Cache hits return immediately — compression and LLM calls are skipped. For high-repetition workloads (customer support, FAQ bots), cache hit rates above 40% are typical.</p></div></div>''', "cache")
    prot = sec("coral", f'''<div class="split"><div class="reveal">{eyebrow("04","Protect")}<h2 class="t-sec m">Protected Zones</h2>
<p class="lead">Medical, legal, and crisis conversations are never compressed, never monetized, and never cached. Not a filter you can turn off. An architectural boundary at the function level.</p>
<p class="lead" style="margin-top:18px">If the classifier returns medical, legal, or crisis, compression is disabled. The full context is forwarded to your LLM unchanged. The response header returns <code>x-cts-protected: true</code>.</p>
<div style="margin-top:28px">{checks(["● Medical: symptoms, diagnoses, prescriptions, procedures","● Legal: contracts, litigation, regulatory, compliance","● Crisis: mental health, self-harm, emergency services"])}</div></div>
<div class="reveal card"><span class="tag">Architectural Boundary</span><p class="t-sub" style="margin-top:22px;font-size:1.35rem;line-height:1.3">Protected zones cannot be disabled by API callers, subscription tier, or configuration. The check happens inside compressHistory() before any other processing.</p>
<div style="display:flex;gap:10px;margin-top:26px;flex-wrap:wrap"><span class="tag fill">Medical</span><span class="tag fill">Legal</span><span class="tag fill">Crisis</span></div>
<p class="note">Protected conversations are not counted toward token quota.</p></div></div>''', "protect")
    mcp = sec("white", f'''<div class="reveal">{eyebrow("05","MCP Server")}<h2 class="t-sec m">Works inside<br>your AI IDE.</h2>
<p class="lead">Native MCP server with 4 tools. Add {BRAND} to Claude Desktop, Cursor, or Windsurf in under 2 minutes.</p></div>
<div class="grid3 mt reveal"><div class="cell"><span class="tag">compress</span><p>Compress a conversation history. Returns the compressed messages array plus classification metadata.</p></div>
<div class="cell"><span class="tag">classify</span><p>Classify a single message or conversation turn. Returns domain, intent, risk level, emotional state.</p></div>
<div class="cell"><span class="tag">remember / recall</span><p>Store and retrieve facts semantically. Persistent across sessions. Works as long-term memory for agents.</p></div></div>
<div class="mt-s" style="margin-top:32px">{btn("Setup guide →","/docs#mcp-server")}</div>''', "mcp")
    proxy = sec("navy", f'''<div class="split"><div class="reveal">{eyebrow("06","OpenAI Proxy")}<h2 class="t-sec m">Drop-in.<br>Any model.</h2>
<p class="lead">{BRAND} exposes a fully OpenAI-compatible /v1/chat/completions endpoint. Change baseURL in your client — nothing else changes.</p>
<div style="margin-top:28px">{btn("Integration docs →","/docs#openai-proxy")}</div></div>
<div class="reveal"><p class="eyebrow">3-line integration</p>{code(f"""const client = new OpenAI({{
 apiKey: process.env.OPENAI_KEY,
 baseURL: 'https://api.{BRAND}.ai/v1',
 defaultHeaders: {{
'x-cts-key': process.env.ECHOREGENT_KEY
 }}
}})""","JavaScript")}</div></div>''', "proxy")
    page("/product", f"Product — {BRAND}", hero + cls + comp + cache + prot + mcp + proxy, desc="Four systems. One API. Context Classifier, History Compressor, Semantic Cache, Protected Zones, MCP Server and OpenAI Proxy.")

# ---------------------------------------------------------------- SOLUTIONS
def cs():
    hero = page_hero("Solutions · Customer Support", "Your support bot remembers. / Your bill doesn't grow.",
        f"Long support threads bloat your context window every turn. {BRAND} compresses the history before each LLM call — same quality, 60% fewer tokens.",
        btn("Get API Key →","/pricing#get-key") + btn("Integration Docs","/docs","btn-ghost"))
    st = sec("white tight", stats([("60%","avg cost reduction"),("<15ms","compression overhead"),("87%","quality match-or-beat"),("0","code changes to integrate")]))
    prob = sec("navy", f'''<div class="split"><div class="reveal">{eyebrow("01","The Problem")}<h2 class="t-sec m">Support threads are LLM cost traps.</h2>
<div class="prose" style="margin-top:26px"><p>A ticket that runs 15 turns sends the full transcript to the LLM on every reply. Turn 15 might be 4,000 tokens of context — 70% of which is greetings, re-explanations, and resolved sub-issues from earlier in the conversation.</p>
<p>You pay for all of it. The model's attention dilutes. Response quality quietly drops. And you have no visibility into why.</p></div></div>
<div class="reveal card" style="background:var(--navy);border:1px solid var(--line-inv)"><span class="tag" style="color:var(--coral)">Without {BRAND}</span>
<ul class="turns" style="margin-top:22px"><li><span>Turn 1</span><span>→ 120 tokens</span></li><li><span>Turn 5</span><span>→ 780 tokens</span></li><li><span>Turn 10</span><span>→ 2,100 tokens</span></li><li><span>Turn 15</span><span style="color:var(--coral)">→ 3,940 tokens</span></li></ul>
<p class="note" style="color:#fff">Cost grows linearly with conversation length</p></div></div>''')
    how = sec("white", f'''<div class="reveal">{eyebrow("02","How It Works")}<h2 class="t-sec m">Compress. Cache. Forward.</h2></div>
<div class="grid3 steps mt reveal"><div class="cell"><h3 class="t-card">Classify the ticket</h3><p>DistilBERT reads the conversation and detects domain (customer support), intent, sentiment, and escalation risk. Runs on CPU in &lt;10ms. No external API call.</p></div>
<div class="cell"><h3 class="t-card">Compress the history</h3><p>T5 summarises resolved earlier turns while preserving unresolved issues, account details, and escalation context. Average 60% reduction for support threads.</p></div>
<div class="cell"><h3 class="t-card">Cache repeated queries</h3><p>MiniLM catches semantically identical questions ("where is my order?", "order status?", "track my package"). Cache hits skip LLM entirely. Savings compound across all users.</p></div></div>''')
    integ = sec("teal", f'''<div class="split"><div class="reveal">{eyebrow("03","Integration")}<h2 class="t-sec m">One URL change.<br>That's it.</h2>
<p class="lead">Works with any support platform that calls an OpenAI-compatible endpoint — Intercom, Zendesk AI, custom bots, in-house tooling.</p></div>
<div class="reveal"><p class="eyebrow">Before → After</p>{code(f"""// Before
const client = new OpenAI({{ apiKey: "sk-..." }})
// with {BRAND}
const client = new OpenAI({{
 apiKey: "sk-...",
 baseURL: "https://api.{BRAND}.ai/v1",
 defaultHeaders: {{ "x-echoregent-key": "your-key" }}
}})""","JavaScript")}</div></div>''')
    cta = sec("coral", f'''<div class="reveal">{eyebrow("04","Get started")}<h2 class="t-sec m">Integrate in under 60 seconds.</h2><p class="lead">Free tier — 10M tokens. No credit card. Works today.</p>
<div class="page-hero"><div class="actions">{btn("Get a free API key →","/pricing#get-key")}{btn("Read the docs","/docs","btn-ghost")}</div></div></div>''')
    page("/solutions/customer-support", f"Customer Support — {BRAND}", hero + st + prob + how + integ + cta, active="/solutions/customer-support", desc="Your support bot remembers. Your bill doesn't grow.")

def coding():
    hero = page_hero("Solutions · Coding Assistants", "Stack traces compress. / Code context doesn't.",
        "Coding sessions accumulate fast — error loops, refactor attempts, dead ends. " + BRAND + " strips the noise while keeping every live code block and unresolved error intact.",
        btn("Get API Key →","/pricing#get-key") + btn("MCP Setup Guide","/docs#mcp","btn-ghost"))
    st = sec("white tight", stats([("72%","reduction on debug sessions"),("4","MCP tools (compress, classify, remember, recall)"),("Native","Cursor · Windsurf · Claude Desktop"),("CPU","no GPU · no external calls")]))
    dom = sec("navy", f'''<div class="reveal">{eyebrow("01","Domain-Aware Compression")}<h2 class="t-sec m">Coding gets its own<br>compression strategy.</h2>
<div class="prose" style="margin-top:26px"><p>Generic summarizers treat code like prose. They compress indiscriminately — and lose the exact stack frame that caused the error, or the function signature that was changed three turns ago.</p>
<p>{BRAND}'s T5 model uses a coding-specific compression strategy: stack traces and error messages compress aggressively (they're noisy). Live code blocks, file names, and unresolved errors are preserved verbatim.</p></div></div>
<div class="compare reveal"><div><span class="tag coral" style="color:var(--coral)">Compresses hard</span><p style="margin-top:18px;font-size:1.1rem">Resolved error messages · Successful run logs · "Let me try..." attempts · Repeated explanations · Dead-end branches</p></div>
<div><span class="tag" style="color:var(--teal)">Preserved verbatim</span><p style="margin-top:18px;font-size:1.1rem">Active code blocks · Unresolved errors · File paths · Function signatures · The current task goal</p></div></div>''')
    mcp = sec("white", f'''<div class="split"><div class="reveal">{eyebrow("02","MCP Integration")}<h2 class="t-sec m">Works inside Cursor, Windsurf, Claude Desktop.</h2>
<p class="lead">The {BRAND} MCP server exposes 4 tools your AI IDE can call directly. No proxy layer needed.</p>
<div class="grid2 mt-s" style="margin-top:32px"><div class="cell"><span class="tag">compress</span><p>Compress the current conversation history. Returns compressed messages + tokens saved + domain classification.</p></div>
<div class="cell"><span class="tag">classify</span><p>Classify the conversation domain and intent. Returns domain, risk level, emotional state, intent.</p></div>
<div class="cell"><span class="tag">remember</span><p>Store a key fact or decision for this session. Persists across context window resets.</p></div>
<div class="cell"><span class="tag">recall</span><p>Retrieve stored facts by keyword. Use at the start of a new session to restore context.</p></div></div></div>
<div class="reveal">{code(f"""{{
  "mcpServers": {{
    "{BRAND}": {{
      "command": "npx",
      "args": ["-y", "@echoregent/mcp-server"],
      "env": {{ "ECHOREGENT_KEY": "your-key" }}
    }}
  }}
}}""","Cursor — mcp.json")}</div></div>''')
    proxy = sec("teal", f'''<div class="split"><div class="reveal">{eyebrow("03","OpenAI Proxy")}<h2 class="t-sec m">Or just change your baseURL.</h2>
<p class="lead">If your coding assistant uses the OpenAI client (Cursor, custom tools, anything built on the SDK), one URL swap wires in compression for every call automatically.</p></div>
<div class="reveal">{code(f"""const client = new OpenAI({{
 apiKey: "sk-...",
 baseURL: "https://api.{BRAND}.ai/v1",
 defaultHeaders: {{ "x-echoregent-key": "your-key" }}
}})""","JavaScript / TypeScript")}</div></div>''')
    cta = sec("coral", f'''<div class="reveal">{eyebrow("04","Get started")}<h2 class="t-sec m">Make your coding assistant cheaper and sharper.</h2><p class="lead">Free tier — 10M tokens, no card required.</p>
<div class="page-hero"><div class="actions">{btn("Get a free API key →","/pricing#get-key")}{btn("Full MCP setup guide","/docs#mcp","btn-ghost")}</div></div></div>''')
    page("/solutions/coding-assistants", f"Coding Assistants — {BRAND}", hero + st + dom + mcp + proxy + cta, active="/solutions/coding-assistants", desc="Stack traces compress. Code context doesn't.")

def agents():
    hero = page_hero("Solutions · AI Agents", "Agents that run for hours / shouldn't cost like it.",
        f"Long-running agents accumulate context debt. Every tool call, every sub-task, every retry adds tokens. {BRAND} compresses the trajectory so agents stay within budget — and stay sharp.",
        btn("Get API Key →","/pricing#get-key") + btn("API Reference","/docs","btn-ghost"))
    st = sec("white tight", stats([("26x","token efficiency vs naive context"),("1000+","turns without context overflow"),("329/s","requests/second (load tested)"),("0","message content stored")]))
    prob = sec("navy", f'''<div class="reveal">{eyebrow("01","The Problem")}<h2 class="t-sec m">Context debt is the silent agent killer.</h2>
<div class="prose" style="margin-top:26px"><p>A research agent that runs 200 turns sends the full trajectory to the LLM at turn 200. Most of that trajectory is completed sub-tasks, failed attempts, and intermediate reasoning that's no longer relevant.</p>
<p>The model's attention dilutes across the noise. It starts repeating itself, losing track of the goal, or hitting the context limit and crashing mid-run.</p>
<p>And you pay for every token in that bloated trajectory — every turn, every call.</p></div></div>
<div class="compare reveal"><div><span class="tag" style="color:var(--coral)">Without {BRAND}</span><p style="margin-top:18px;font-size:1.1rem">Token cost grows linearly with agent turns. A 200-turn run costs 200x more than turn 1. Attention degrades. Context limits crash long runs.</p></div>
<div><span class="tag" style="color:var(--teal)">with {BRAND}</span><p style="margin-top:18px;font-size:1.1rem">Completed sub-tasks compress. Active goals stay intact. Context window stays bounded. The agent runs indefinitely on a predictable per-turn cost.</p></div></div>''')
    arch = sec("white", f'''<div class="reveal">{eyebrow("02","Architecture")}<h2 class="t-sec m">Drop in before the LLM call. Nothing else changes.</h2></div>
<div class="grid3 steps mt reveal"><div class="cell"><h3 class="t-card">Intent tracking</h3><p>DistilBERT classifies each turn's intent, domain, and risk. The compressor uses this to decide what's safe to summarise vs. what must be preserved verbatim.</p></div>
<div class="cell"><h3 class="t-card">Trajectory compression</h3><p>Completed tool calls, resolved sub-tasks, and dead-end branches compress aggressively. Active goals, current state, and unresolved errors are kept in full.</p></div>
<div class="cell"><h3 class="t-card">Session memory</h3><p>Use the remember and recall MCP tools to store key facts outside the context window entirely. The agent retrieves them on demand — zero tokens until needed.</p></div></div>''')
    integ = sec("teal", f'''<div class="reveal">{eyebrow("03","Integration")}<h2 class="t-sec m">Works with any agent framework.</h2>
<p class="lead">LangChain, LlamaIndex, AutoGen, CrewAI, custom loops — if it calls an OpenAI-compatible endpoint, you change one URL.</p></div>
<div class="split mt"><div class="reveal">{code(f"""from langchain_openai import ChatOpenAI
llm = ChatOpenAI(
 api_key="sk-...",
 base_url="https://api.{BRAND}.ai/v1",
 default_headers={{"x-echoregent-key": "your-key"}}
)
# Every agent call now compresses history automatically""","Python — LangChain example")}</div>
<div class="reveal">{code(f"""const result = await fetch('https://api.{BRAND}.ai/compress', {{
 method: 'POST',
 headers: {{
'Authorization': 'Bearer your-key',
'Content-Type': 'application/json'
 }},
 body: JSON.stringify({{ messages: agentHistory }})
}})
// result.compressed → drop into next LLM call
// result.tokensSaved → track cost reduction""","Direct /compress API — custom agent loops")}</div></div>''')
    priv = sec("white", f'''<div class="reveal">{eyebrow("04","Privacy")}<h2 class="t-sec m">Agent trajectories never leave the pipeline.</h2></div>
<div class="grid2 mt reveal"><div class="cell"><h3 class="t-card">No message storage</h3><p>Agent trajectories are processed in memory. Nothing is stored after compression completes. No logs of message content, no buffers, no training data collection.</p></div>
<div class="cell"><h3 class="t-card">Response header proof</h3><p>Every call returns x-echoregent-tokens-saved, x-echoregent-domain, and x-echoregent-protected so you can verify behaviour at the application level.</p></div></div>''')
    cta = sec("coral", f'''<div class="reveal">{eyebrow("05","Get started")}<h2 class="t-sec m">Build agents that run longer for less.</h2><p class="lead">Free tier — 10M tokens. No credit card. Works today.</p>
<div class="page-hero"><div class="actions">{btn("Get a free API key →","/pricing#get-key")}{btn("See the benchmark numbers","/research","btn-ghost")}</div></div></div>''')
    page("/solutions/ai-agents", f"AI Agents — {BRAND}", hero + st + prob + arch + integ + priv + cta, active="/solutions/ai-agents", desc="Agents that run for hours shouldn't cost like it.")
