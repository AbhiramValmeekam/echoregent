from lib import *

def feat_cells(items):
    return "".join(f'<div class="cell"><h3 class="t-card">{a}</h3><p>{b}</p></div>' for a, b in items)

# ---------------------------------------------------------------- ENTERPRISE
def enterprise():
    hero = page_hero("Enterprise", "Context infrastructure / built for teams.",
        "Custom token volume. SLA guarantees. On-prem or VPC deployment. Dedicated support from the engineers who built it.",
        btn("Request a Demo","#contact") + btn("Email Us Directly →","mailto:team@yudi.co.in","btn-ghost"))
    why = sec("white", f'''<div class="reveal">{eyebrow("01","Why Enterprise")}<h2 class="t-sec m">The problems we solve<br>at scale.</h2></div><div class="grid3 mt reveal">''' + feat_cells([
        ("LLM costs compounding", f"At 10M+ API calls/month, token costs become the largest line item. {BRAND}'s 64.7% average reduction translates to $40k–$200k saved annually at scale."),
        ("Compliance requirements", f"Medical, legal, and financial conversations can't be compressed or monetized. {BRAND}'s protected zones are architectural — not configurable by end users, not bypassable by API callers."),
        ("Latency at every layer", f"{BRAND}'s three models run on CPU, sub-20ms end to end. No GPU cold starts. No external API calls before your LLM call. 17ms p50 at 329 req/s."),
        ("Multi-tenant isolation", f"Per-key rate limiting, quota enforcement, and usage analytics out of the box. Build products on top of {BRAND} without building billing infrastructure yourself."),
        ("AI agent memory", f"Long-running agents accumulate unbounded context. {BRAND}'s semantic cache + compression keeps agent memory bounded without losing relevant state."),
        ("Multi-provider routing", f"Enterprise teams use multiple LLM providers for cost, compliance, and capability reasons. {BRAND}'s proxy routes to OpenAI, Anthropic, Gemini, and custom endpoints from one integration.")]) + "</div>")
    ef = sec("navy", f'''<div class="reveal">{eyebrow("02","Enterprise Features")}<h2 class="t-sec m">Everything on Pro,<br>plus these.</h2></div><div class="grid4 mt reveal">''' + "".join(
        f'<div class="cell dk"><span class="eyebrow">0{i+1}</span><h3 class="t-card">{a}</h3><p>{b}</p></div>' for i, (a, b) in enumerate([
        ("On-premise / VPC deployment", f"Run {BRAND} entirely within your own infrastructure. Docker image + Helm chart provided. Zero data egress."),
        ("Custom SLA — up to 99.95% uptime", "Contractual uptime guarantees with financial penalties. Dedicated Cloud Run instances, not shared infrastructure."),
        ("Security review &amp; pen test access", "Full architecture review, penetration test results, and a dedicated security contact for your compliance team."),
        ("Custom domain", f"Host the proxy at ai.yourdomain.com instead of api.{BRAND}.ai. Useful for white-labeling and internal tooling."),
        ("Dedicated support engineer", "A named engineer from Yudi Labs responds to your Slack channel or email within 4 business hours."),
        ("Unlimited token volume", "No monthly cap. Custom rate limits tuned for your traffic patterns. Burst capacity negotiated in contract."),
        ("Custom domain classifications", "Add proprietary domains to the classifier fine-tuned on your conversation data. Accuracy tested before deployment."),
        ("Usage analytics &amp; cost dashboard", "Per-key, per-endpoint breakdowns. Export to CSV or connect to your existing data warehouse via webhook.")])) + "</div>")
    sla = sec("white", f'''<div class="reveal">{eyebrow("03","SLA")}<h2 class="t-sec m">Guarantees in writing.</h2></div><div class="mt reveal">''' + table(
        ["Metric","Starter","Pro","Enterprise"],
        [["Uptime SLA","—","99.9%","99.95% custom"],["p50 latency","&lt;30ms","&lt;20ms","&lt;15ms dedicated"],["Support response","Email / 48h","Priority / 24h","Dedicated / 4h"],
         ["Incident notification","Status page","Status page","Direct alert"],["Data residency","Shared GCP","Shared GCP","Your VPC / on-prem"],["Security review","—","—",""],["Custom contract","—","—",""]]) + "</div>")
    contact = sec("teal", f'''<div class="split" id="contact"><div class="reveal">{eyebrow("04","Contact Sales")}<h2 class="t-sec m">Let's talk.</h2>
<p class="lead">Tell us about your use case. We'll come back within one business day with a custom proposal.</p>
<p class="lead" style="font-size:1rem">Or email us directly: <a href="mailto:team@yudi.co.in" style="text-decoration:underline">team@yudi.co.in</a></p></div>
<form class="form reveal" id="ent-form" novalidate>
<label>Name<input id="e-name" autocomplete="name"></label><label>Work email<input id="e-email" type="email" autocomplete="email"></label>
<label>Company &amp; role<input id="e-company"></label>
<label>Estimated monthly API calls<select id="e-volume"><option value="">Select volume...</option><option>Under 1M / month</option><option>1M – 10M / month</option><option>10M – 100M / month</option><option>100M+ / month</option></select></label>
<label>Tell us about your use case<textarea id="e-use"></textarea></label>
<div class="msg" id="e-err"></div><div class="msg" id="e-ok"></div>
<button class="btn" id="e-btn" type="submit">Send to Sales Team →</button></form></div>''')
    page("/enterprise", f"Enterprise — {BRAND}", hero + why + ef + sla + contact, active="/enterprise", desc="Context infrastructure built for teams.")

# ---------------------------------------------------------------- RESEARCH
def research():
    hero = page_hero("Research & Benchmarks", "26× fewer tokens. / Better quality.",
        "Measured on LoCoMo — the same benchmark mem0 uses in their published paper. Every number on this page is reproducible. Every claim is cited.")
    st = sec("white tight", stats([("26.8×","Token efficiency vs mem0 on LoCoMo"),("259",f"Mean tokens per query ({BRAND})"),("6,956","Mean tokens per query (mem0)*"),("87%","Quality match-or-beat rate"),("329/s","Throughput · 0 errors")]) +
        '<p class="note">* mem0\'s 6,956 token figure is their own published number from the mem0 blog ("mem0: The Token-Efficient Memory Algorithm," 2024).</p>')
    lo = sec("navy", f'''<div class="reveal">{eyebrow("01","LoCoMo Benchmark")}<h2 class="t-sec m">Same dataset.<br>Different architecture.</h2>
<p class="lead">LoCoMo (Long-term Conversational Memory) is a benchmark for evaluating how well memory systems retain and retrieve information from long conversations. It's the benchmark mem0 chose for their published evaluation — we ran the same test.</p></div>
<div class="mt reveal">''' + table(["System","Mean tokens / query","F1 score","Efficiency ratio","On-device","Protected zones"],
        [[BRAND,"259","0.079","26.8× fewer","",""],["mem0","6,956 *","N/A †","1× (baseline)","—","—"],["Full context (no memory)","~18,679","0.069","0.37× (worse)","—","—"]], hl=0) +
        '<p class="note" style="color:#fff">* mem0 token figure from mem0.ai/blog (2024). † mem0 quality measured via LLM-as-judge on a 0–100 scale — not directly comparable to token-overlap F1. We report F1 because it\'s dataset-verifiable.</p></div>' +
        f'''<div class="grid2 mt reveal"><div class="cell dk"><span class="tag" style="color:var(--coral)">Key Finding</span><p style="font-size:1.1rem">{BRAND} compresses 26.8× harder than mem0 while achieving a higher F1 score (0.079 vs full-context baseline of 0.069). Compression preserved more relevant signal than no compression at all.</p></div>
<div class="cell dk"><span class="tag" style="color:var(--teal)">What This Means</span><p style="font-size:1.1rem">At 259 tokens vs mem0's 6,956 — if you're running 1M queries/month, {BRAND} saves ~6.7B tokens per month versus mem0's approach. At $0.50/1M input tokens, that's $3,350/month saved.</p></div></div>''')
    qe = sec("white", f'''<div class="reveal">{eyebrow("02","Quality Evaluation")}<h2 class="t-sec m">Compressed context.<br>Uncompromised answers.</h2>
<p class="lead">120 conversations across three datasets, scored by Gemini-as-judge on a 1–10 scale. {BRAND} vs full context — who answers better?</p></div>
<div class="split mt"><div class="reveal"><span class="eyebrow">Quality</span><h3 class="t-sub" style="margin:8px 0 0">Gemini-as-Judge Scores</h3>
<div class="stats" style="grid-template-columns:1fr 1fr"><div><div class="stat-n">9.0 / 10</div><div class="eyebrow stat-l">{BRAND} avg score</div></div><div><div class="stat-n" style="color:var(--gray)">8.7 / 10</div><div class="eyebrow stat-l">Full context avg score</div></div>
<div><div class="stat-n">87%</div><div class="eyebrow stat-l">{BRAND} match-or-beat rate</div></div><div><div class="stat-n">120</div><div class="eyebrow stat-l">Conversations evaluated</div></div></div></div>
<div class="reveal"><span class="eyebrow">Datasets</span><h3 class="t-sub" style="margin:8px 0 0">Evaluation Corpus</h3>
<div class="rows" style="margin-top:20px"><div><h4 class="t-card">SQuAD 2.0</h4><p>Reading comprehension · factual recall · multi-turn</p></div><div><h4 class="t-card">Stack Overflow (coding)</h4><p>Code debugging · long error traces · step-by-step solutions</p></div><div><h4 class="t-card">Medical QA (excluded from compression)</h4><p>Protected zone · full context preserved · control group</p></div></div></div></div>''')
    lt = sec("coral", f'''<div class="reveal">{eyebrow("03","Load Test")}<h2 class="t-sec m">Production-grade.<br>Day one.</h2>
<p class="lead">10M token load test at scale. {BRAND} runs on Cloud Run with min-instances=1 — no cold starts on critical paths.</p></div>''' +
        stats([("329","Requests / second"),("17ms","p50 latency"),("64.7%","Token reduction"),("0","Errors")]).replace('class="stats reveal"', 'class="stats reveal" style="color:var(--navy)"'))
    uh = sec("white", f'''<div class="reveal">{eyebrow("04","Under the Hood")}<h2 class="t-sec m">Three models.<br>No cloud dependencies.</h2>
<p class="lead">Every model runs on CPU. No GPU required, no external embedding calls, no data leaving your stack.</p></div><div class="grid3 mt reveal">
<div class="cell"><span class="tag">Classify</span><h3 class="t-sub" style="margin-top:20px">DistilBERT</h3><p>Fine-tuned on 10 conversation domains. Returns domain, intent, risk level, and emotional state. Runs in under 10ms on CPU.</p></div>
<div class="cell"><span class="tag">Compress</span><h3 class="t-sub" style="margin-top:20px">T5</h3><p>Sequence-to-sequence compression. Removes conversational noise while preserving semantic meaning. Domain-aware — medical conversations skip compression entirely.</p></div>
<div class="cell"><span class="tag">Cache</span><h3 class="t-sub" style="margin-top:20px">MiniLM</h3><p>384-dimensional semantic embeddings. Detects semantically equivalent queries before compression. Cache lookup under 5ms.</p></div></div>''')
    rep = sec("navy", f'''<div class="split"><div class="reveal">{eyebrow("05","Reproducibility")}<h2 class="t-sec m">Every number is<br>reproducible.</h2><p class="lead">All evaluation code is open source. Run the same benchmarks yourself.</p></div>
<div class="reveal"><h3 class="t-sub">Run the LoCoMo eval</h3><p class="lead" style="margin-top:12px">The evaluation harness, datasets, and scoring scripts are all in the open repo. Requires an {BRAND} API key (free tier works).</p>
{code(f"git clone https://github.com/ashy5454/echoregent\ncd {BRAND}\nnpm run eval:dataset","Terminal")}</div></div>''')
    page("/research", f"Research — {BRAND} Benchmarks", hero + st + lo + qe + lt + uh + rep, active="/research", desc="26× fewer tokens. Better quality. Measured on LoCoMo.")

# ---------------------------------------------------------------- DOCS
def docs():
    P = BRAND
    side = [("Getting Started",[("Quick Start","quickstart"),("Authentication","authentication"),("Free Tier & Limits","free-tier")]),
            ("Integration",[("OpenAI Proxy","openai-proxy"),("MCP Server","mcp-server"),("Direct API","direct-api"),("Python SDK","python")]),
            ("API Reference",[("POST /compress","compress-endpoint"),("POST /v1/chat/completions","proxy-endpoint"),("GET /usage","usage-endpoint")]),
            ("Configuration",[("Response Headers","response-headers"),("Protected Zones","protected-zones"),("Rate Limits","rate-limits"),("Supported Domains","domains")]),
            ("Guides",[("Cursor Setup","cursor-guide"),("Claude Desktop","claude-desktop"),("Windsurf Setup","windsurf-guide")])]
    sb = '<aside class="side" aria-label="Docs navigation">' + "".join(f"<h5>{e(t)}</h5>" + "".join(f'<a href="#{i}">{e(l)}</a>' for l, i in items) for t, items in side) + "</aside>"
    c = f'''<div><div class="eb-row"><span class="ln"></span><span class="lb">{P} › Documentation</span></div><h1 class="t-sec m" style="margin-bottom:20px">Integration Guide</h1>
<p class="lead" style="margin-top:0">{P} sits between your application and any LLM. Three integration paths: OpenAI-compatible proxy (recommended), native MCP server, or direct REST API.</p>
<div class="callout"><b>Free Tier Active</b><span>10M tokens/month at no cost. No credit card required.</span><a href="{L("/pricing#get-key")}">Get your API key →</a></div>

<section class="dsec" id="quickstart"><h2>Quick Start</h2><p>The fastest path: change one URL in your existing OpenAI client. Your code stays exactly the same — {P} intercepts, classifies, compresses, and forwards to your LLM.</p>
<h3>Step 1 — Get your API key</h3><p>Request a free key at <a href="{L("/pricing#get-key")}" style="text-decoration:underline">{P}.ai/pricing</a>. It arrives by email within 60 seconds.</p>
<h3>Step 2 — Point your client at {P}</h3>
{code(f"""import OpenAI from 'openai'
const client = new OpenAI({{
 apiKey: process.env.OPENAI_API_KEY, // your existing LLM key
 baseURL: 'https://api.{P}.ai/v1',
 defaultHeaders: {{
'x-echoregent-key': process.env.ECHOREGENT_KEY, // your EchoRegent key
 }}
}})
// Everything else stays identical
const response = await client.chat.completions.create({{
 model: 'gpt-4o',
 messages: conversationHistory // {P} compresses this automatically
}})""","JavaScript / TypeScript")}
{code(f"""from openai import OpenAI
client = OpenAI(
 api_key="sk-...", # your existing LLM key
 base_url="https://api.{P}.ai/v1",
 default_headers={{
"x-echoregent-key": "your-echoregent-key"
 }}
)
# Your calls stay identical
response = client.chat.completions.create(
 model="gpt-4o",
 messages=conversation_history
)""","Python")}
<h3>Step 3 — Read what was saved</h3><p>Every response includes {P} headers showing exactly what happened:</p>
{code("""x-echoregent-tokens-saved: 1,842
x-echoregent-domain: coding
x-echoregent-intent: debugging
x-echoregent-compression-pct: 67
x-echoregent-cache-hit: false
x-echoregent-protected: false""","Response headers")}</section>

<section class="dsec" id="authentication"><h2>Authentication</h2><p>{P} uses two separate keys: your {P} key for billing and rate limiting, and your LLM provider key which is forwarded to the upstream model.</p>
<div class="mt-s" style="margin-top:20px">{table(["Header","Value","Purpose"],[["<code>x-echoregent-key</code>",f"Your {P} API key","Billing, rate limit, quota"],["<code>x-llm-key</code>","Your LLM provider key (OpenAI, etc.)","Forwarded to upstream model"],["<code>x-llm-provider</code>","openai · anthropic · gemini","Which provider to route to"]])}</div>
<p>When using the OpenAI-compatible proxy, your LLM key is passed as <code>Authorization: Bearer sk-...</code> and {P} forwards it transparently to the upstream model. It is never stored.</p></section>

<section class="dsec" id="free-tier"><h2>Free Tier &amp; Limits</h2>{table(["Tier","Monthly tokens","Rate limit","Price"],[["Free","10M","60 req/min","$0"],["Starter","50M","200 req/min","$199/mo"],["Pro","250M","500 req/min","$499/mo"],["Agency","Unlimited","Custom","$999/mo"]])}
<p>Token counts refer to tokens saved, not tokens processed. The demo endpoint (<code>/demo/compress</code>) allows up to 20 requests/minute per IP without an API key — for testing only.</p></section>

<section class="dsec" id="openai-proxy"><h2>OpenAI Proxy</h2><p>The recommended integration. {P} exposes a fully OpenAI-compatible <code>/v1/chat/completions</code> endpoint. Change your baseURL — nothing else changes in your codebase.</p>
<p><span class="method">POST</span><code>/v1/chat/completions</code></p><p>{P} intercepts the request, runs the classify + compress pipeline on messages, then forwards the compressed payload to your upstream model. The response you receive is identical to what your LLM returns — {P} adds its headers and steps aside.</p>
<h3>Supported providers via proxy</h3><ul class="plain"><li>OpenAI (GPT-4o, GPT-4o-mini, o1, o3)</li><li>Anthropic (Claude 3.5, Claude Sonnet 4.6)</li><li>Google (Gemini 2.0 Flash, Gemini 1.5 Pro)</li><li>Mistral, Groq, Together, or any OpenAI-compatible endpoint</li></ul>
<h3>Specifying a non-OpenAI provider</h3>{code(f"""const client = new OpenAI({{
 apiKey: process.env.ANTHROPIC_KEY,
 baseURL: 'https://api.{P}.ai/v1',
 defaultHeaders: {{
'x-echoregent-key': process.env.ECHOREGENT_KEY,
'x-llm-provider': 'anthropic',
 }}
}})""","Route to Anthropic via proxy")}</section>

<section class="dsec" id="mcp-server"><h2>MCP Server</h2><p>{P} ships a native MCP (Model Context Protocol) server. Four tools are available immediately — compress, classify, remember, and recall. Works with Claude Desktop, Cursor, Windsurf, and any MCP client.</p>
<h3>Available MCP Tools</h3>{table(["Tool","Description","Input"],[["<code>compress</code>","Compress conversation history","messages array"],["<code>classify</code>","Classify domain, intent, risk","message text"],["<code>remember</code>","Store a fact in semantic memory","key, value, session"],["<code>recall</code>","Retrieve semantically similar facts","query, session"]])}</section>

<section class="dsec" id="direct-api"><h2>Direct API</h2><p>Call {P} directly without going through the proxy. Useful when you want to pre-process context before assembling your LLM request.</p></section>

<section class="dsec" id="python"><h2>Python SDK</h2><p>See the Python example in <a href="#quickstart" style="text-decoration:underline">Quick Start</a>.</p></section>

<section class="dsec" id="compress-endpoint"><h2>POST /compress</h2><p><span class="method">POST</span><code>https://api.{P}.ai/compress</code></p><p>Requires <code>Authorization: Bearer &lt;your-echoregent-key&gt;</code> header.</p>
{code("""{
  "messages": [
    { "role": "user", "content": "..." },
    { "role": "assistant", "content": "..." }
  ],
  "options": {
    "maxTokens": 4096, // optional target window
    "preserveLast": 2 // always keep last N turns uncompressed
  }
}""","Request body")}
{code("""{
  "compressed": [ /* compressed messages array */ ],
  "domain": "coding",
  "intent": "debugging",
  "tokensSaved": 1842,
  "compressionPct": 67,
  "protected": false,
  "cacheHit": false
}""","Response")}</section>

<section class="dsec" id="proxy-endpoint"><h2>POST /v1/chat/completions</h2><p><span class="method">POST</span><code>https://api.{P}.ai/v1/chat/completions</code></p>
<p>Fully OpenAI-compatible. Accepts the exact same body as <code>openai.chat.completions.create()</code>. {P} compresses the messages field, then forwards to your upstream model. Returns the upstream response unmodified plus {P} headers.</p>
<p>Additional headers required:</p><ul class="plain"><li><code>x-echoregent-key</code> — your EchoRegent key</li><li><code>x-llm-key</code> — your upstream LLM API key (optional if using Authorization: Bearer)</li><li><code>x-llm-provider</code> — openai (default) · anthropic · gemini</li></ul></section>

<section class="dsec" id="usage-endpoint"><h2>GET /usage</h2><p><span class="method">GET</span><code>/usage</code></p></section>

<section class="dsec" id="response-headers"><h2>Response Headers</h2>{table(["Header","Type","Description"],[["<code>x-echoregent-tokens-saved</code>","integer","Tokens removed from context"],["<code>x-echoregent-compression-pct</code>","integer 0–100","% reduction in context length"],["<code>x-echoregent-domain</code>","string","Detected conversation domain"],["<code>x-echoregent-intent</code>","string","Detected intent"],["<code>x-echoregent-cache-hit</code>","boolean","Whether response came from semantic cache"],["<code>x-echoregent-protected</code>","boolean","True if compression was disabled (medical/legal/crisis)"]])}</section>

<section class="dsec" id="protected-zones"><h2>Protected Zones</h2><p>Three conversation types are architecturally protected from compression:</p>
<div class="card bd" style="margin-top:20px"><span class="eyebrow">Protected — compression disabled</span><p style="margin-top:12px">When the classifier detects one of these domains, the compression step is skipped entirely. The full context is forwarded. These zones cannot be overridden by API callers.</p>
<div style="display:flex;gap:10px;margin-top:18px;flex-wrap:wrap"><span class="tag fill">Medical</span><span class="tag fill">Legal</span><span class="tag fill">Crisis</span></div></div>
<p>Protected conversations return <code>x-echoregent-protected: true</code> and are not counted toward your quota.</p></section>

<section class="dsec" id="rate-limits"><h2>Rate Limits</h2><p>Rate limits are per API key, per minute. Exceeding the limit returns HTTP 429 with a <code>Retry-After</code> header.</p>
<div style="margin-top:20px">{table(["Tier","Requests/min","Burst"],[["Demo (no key)","20 / IP","—"],["Free","60","80"],["Starter","200","300"],["Pro","500","700"],["Agency","Custom","Custom"]])}</div></section>

<section class="dsec" id="domains"><h2>Supported Domains</h2><p>The classifier returns one of these domain values per conversation turn:</p>
<ul class="plain"><li><code>coding</code> — software development, debugging, code review</li><li><code>medical</code> — health, symptoms, medications <span class="tag fill">⬥ Protected</span></li><li><code>legal</code> — contracts, compliance, advice <span class="tag fill">⬥ Protected</span></li><li><code>crisis</code> — mental health, emergency <span class="tag fill">⬥ Protected</span></li><li><code>customer_support</code> — tickets, complaints, returns</li><li><code>sales</code> — outreach, negotiation, CRM</li><li><code>finance</code> — budgeting, investing, accounting</li><li><code>education</code> — tutoring, explanations</li><li><code>creative</code> — writing, brainstorming, ideation</li><li><code>general</code> — catch-all for uncategorized</li></ul></section>

<section class="dsec" id="cursor-guide"><h2>Cursor Setup</h2><p>Add to your <code>~/.cursor/mcp.json</code>:</p>
{code(f"""{{
  "mcpServers": {{
    "{P}": {{
      "url": "https://api.{P}.ai/mcp",
      "headers": {{
        "x-echoregent-key": "your-echoregent-key"
      }}
    }}
  }}
}}""","~/.cursor/mcp.json")}</section>

<section class="dsec" id="claude-desktop"><h2>Claude Desktop Setup</h2>
{code(f"""{{
  "mcpServers": {{
    "{P}": {{
      "command": "npx",
      "args": ["-y", "@echoregent/mcp-server"],
      "env": {{ "ECHOREGENT_KEY": "your-key" }}
    }}
  }}
}}""","claude_desktop_config.json")}</section>

<section class="dsec" id="windsurf-guide"><h2>Windsurf Setup</h2><p>Add to your Windsurf MCP configuration file at <code>~/.windsurf/mcp_config.json</code>:</p>
{code(f"""{{
"servers": {{
"{P}": {{
"serverUrl": "https://api.{P}.ai/mcp",
"auth": {{
"type": "header",
"header": "x-echoregent-key",
"value": "your-echoregent-key"
 }}
 }}
 }}
}}""","~/.windsurf/mcp_config.json")}</section>

<div class="card bd" style="margin-top:20px"><h3 class="t-card">Need help?</h3><p style="margin-top:10px">Email <a href="mailto:team@yudi.co.in" style="text-decoration:underline">team@yudi.co.in</a> — we respond within 24 hours. For enterprise support and SLAs, see the <a href="{L("/enterprise")}" style="text-decoration:underline">Enterprise page</a>.</p></div></div>'''
    page("/docs", f"Docs — {P} Integration Guide", f'<div class="wrap docs">{sb}{c}</div>', active="/docs", desc="Integration guide")

# ---------------------------------------------------------------- PRICING
def pricing():
    P = BRAND
    hero = page_hero("Simple Pricing", "Start free. / Scale when you grow.", "10M tokens free every month. No credit card. Sign in with Google — your API key is ready instantly.")
    feats = "<li>{}</li>"
    def plan(cls, name, price, toks, supp, cta, badge=""):
        b = f'<span class="pop-b">{badge}</span>' if badge else ""
        return (f'<div class="plan {cls}">{b}<span class="eyebrow">{name}</span><div class="price">{price}</div><div class="per">{"forever · no card" if name=="Free" else "per month"}</div>'
                f'<ul><li>{toks}</li><li>All 10 domains</li><li>Protected zones</li><li>MCP server</li><li>OpenAI proxy</li><li>{supp}</li></ul>{cta}</div>')
    soon = '<div class="soon">Coming Soon</div>'
    plans = ('<div class="plans reveal">' + plan("", "Free", "$0", "10M tokens / month", "Community support", btn("Get API Key →", "/login", "btn"))
        + plan("pop", "Starter", "$199", "50M tokens / month", "Email support", soon, "Most Popular")
        + plan("", "Pro", "$499", "250M tokens / month", "Priority support", soon)
        + plan("", "Agency", "$999", "Unlimited tokens", "Dedicated support", soon) + '</div>')
    mail = "mailto:team@yudi.co.in?subject=Prexi%20—%20Higher%20Limits&body=Hi%20Ashmith%2C%0A%0AI%27d%20like%20to%20discuss%20higher%20limits%20for%20my%20Prexi%20account.%0A%0A%5BDescribe%20your%20use%20case%20and%20expected%20token%20volume%5D"
    p1 = sec("white tight", plans + f'<p class="note" style="margin-top:28px">Need higher limits or a custom plan? <a href="{mail}" style="text-decoration:underline">Contact us →</a></p>')
    ck = "✓"
    rows = [["Monthly tokens","10M","50M","250M","Unlimited"],["Rate limit (req/min)","60","200","500","Custom"]] + [[n]+[ck]*4 for n in ["Context Classifier","History Compressor","Semantic Cache","Protected Zones","MCP Server","OpenAI Proxy","All 10 domains","Usage analytics"]] + [["Support","Community","Email","Priority","Dedicated"],["SLA","—","—","99.9%","99.95% custom"],["Custom domain","—","—","—",ck],["On-prem / VPC","—","—","—",ck]]
    cmp_ = sec("navy", f'<div class="reveal">{eyebrow("01","Compare Plans")}<h2 class="t-sec m">Everything in every plan.</h2></div><div class="mt reveal">{table(["Feature","Free","Starter","Pro","Agency"],rows)}</div>')
    key = sec("teal", f'''<div class="split" id="get-key"><div class="reveal">{eyebrow("02","Free Tier")}<h2 class="t-sec m">Get your API key instantly.</h2>
<p class="lead">10M tokens free every month. No credit card. Sign in with Google and your key is ready on the next screen.</p></div>
<div class="reveal card"><a class="btn" href="{L("/login")}" style="width:100%;justify-content:center">Sign in with Google — get your key</a><p class="note" style="margin-top:22px">Already have a key? <a href="/dashboard" style="text-decoration:underline">Go to dashboard →</a></p></div></div>''')
    faqs = [('What counts as a "token"?', f"Tokens saved — not tokens processed. We count the difference between your original context length and the compressed length. If you send 2,000 tokens and {P} reduces it to 680, you're charged for 1,320 saved tokens."),
      ("Do you store my conversation data?", f"No. {P} processes conversations in-memory and discards them immediately after compression. Your LLM provider key is never stored. Protected zone conversations (medical/legal/crisis) are never touched by the compression pipeline at all."),
      ("What if I exceed my monthly token limit?", "Your API key returns 402 responses until the next billing cycle. You won't be automatically charged. Upgrade your plan from the dashboard or email us for an immediate increase."),
      ("Can I use this with any LLM provider?", "Yes. The OpenAI proxy supports OpenAI, Anthropic, Gemini, Mistral, Groq, Together, and any OpenAI-compatible endpoint. For direct API calls, you handle routing yourself."),
      ("Is there an enterprise plan?", f'Yes. Custom token volume, SLAs, on-prem/VPC deployment, dedicated support, and security review. <a href="{L("/enterprise")}" style="text-decoration:underline">See the Enterprise page</a> or email team@yudi.co.in.')]
    fq = sec("white", f'<div class="split"><div class="reveal">{eyebrow("03","FAQ")}<h2 class="t-sec m">Common questions.</h2></div><div class="faq reveal">' +
        "".join(f'<details><summary>{e(q)}</summary><div class="a">{a}</div></details>' for q, a in faqs) + "</div></div>")
    page("/pricing", f"Pricing — {P}", hero + p1 + cmp_ + key + fq, active="/pricing", desc="Start free. Scale when you grow.")

# ---------------------------------------------------------------- BLOG
def blog():
    P = BRAND
    hero = page_hero("Blog", "From the team.", "Research findings, product updates, and thinking about context management for AI.")
    posts = [("Research","June 2024","We beat mem0 by 26× on their own benchmark.","LoCoMo is the benchmark mem0 uses in their published paper. We ran the same test. "+P+" uses 259 tokens per query. mem0 uses 6,956 — their own published number. Here's how.",("26×","Token efficiency vs mem0"),False),
      ("Product","June 2024",f"Introducing {P}: the context management layer LLMs were missing.","What remains after compression should be the signal — not the noise. We built a three-model pipeline that classifies, compresses, and protects every conversation before it reaches your LLM.",None,False),
      ("Architecture","Coming soon","Why medical conversations should never be compressed.","Protected zones aren't a feature — they're an architectural decision. The case for hard floors in AI infrastructure.",None,True),
      ("Guide","Coming soon",f"Add {P} to Cursor in 2 minutes.","Step-by-step setup for the MCP server — Claude Desktop, Cursor, and Windsurf. Four tools, one config file.",None,True),
      ("Research","Ongoing","Full benchmark methodology and reproducibility guide.","All evaluation code is open source. Run the LoCoMo eval yourself. Every number on the research page is reproducible.",None,False)]
    items = ""
    for cat, d, t, x, st, soon in posts:
        s = f'<div style="margin-top:12px"><span class="stat-n" style="color:var(--teal)">{st[0]}</span> <span class="eyebrow">{st[1]}</span></div>' if st else ""
        items += f'<article class="post {"soon-p" if soon else ""} reveal"><div class="meta"><span class="tag">{cat}</span><span class="eyebrow">{d}</span></div><h2 class="t-sub">{t}</h2><p style="max-width:44rem">{x}</p>{s}</article>'
    page("/blog/", f"Blog — {P}", hero + sec("white", items), active="/blog/", desc="Research findings, product updates, and thinking about context management for AI.")

# ---------------------------------------------------------------- CHANGELOG
def changelog():
    hero = page_hero("Changelog", "What's new.", "Every release, documented. No dark patterns, no buried breaking changes.")
    rel = [("v0.4","June 2024","OpenAI proxy, MCP server, SaaS billing",True,[("+","OpenAI-compatible proxy — /v1/chat/completions endpoint. Change baseURL, nothing else."),("+","Native MCP server — 4 tools: compress, classify, remember, recall. Claude Desktop, Cursor, Windsurf."),("+","SaaS billing layer — API key management, per-key quotas, usage logging, admin dashboard."),("+","Demo endpoints — /demo/compress and /demo/request-key, no auth required, 20 req/min per IP."),("+","Resend integration — automated API key delivery emails."),("+","Cloud Run deployment — 4GiB memory, min-instances=1, no cold starts.")]),
      ("v0.3","May 2024","Protected zones, eval harness, load test",False,[("+","Protected zones — medical, legal, crisis detection. Compression disabled at function level."),("+","LoCoMo eval harness — npm run eval:dataset. Reproducible benchmark results."),("+","Load test — 329 req/s, 17ms p50, 0 errors on 10M token run."),("+","Quality eval — Gemini-as-judge on 120 conversations. 87% match-or-beat rate vs full context."),("!","Breaking — /classify removed. Classification is now part of /compress response.")]),
      ("v0.2","April 2024","T5 compression + semantic cache",False,[("+","T5 compression — sequence-to-sequence summarisation. Domain-aware strategy selection."),("+","MiniLM semantic cache — 384-dim embeddings, cosine similarity threshold, sub-5ms lookup."),("+","Response headers — x-cts-tokens-saved, x-cts-domain, x-cts-compression-pct, x-cts-cache-hit.")]),
      ("v0.1","March 2024","DistilBERT classifier, initial API",False,[("+","DistilBERT domain classifier — 10 domains, intent detection."),("+","Initial REST API — POST /compress with Bearer auth."),("+","JSON file fallback — works without a database in local development.")])]
    out = ""
    for v, d, t, latest, items in rel:
        li = "".join(f'<li class="{"brk" if s=="!" else ""}"><b>{s}</b><span>{x}</span></li>' for s, x in items)
        lt = '<span class="tag fill">Latest</span>' if latest else ""
        out += f'<div class="reveal"><div><div class="ver">{v}</div><div class="eyebrow" style="margin-top:10px">{d}</div><div style="margin-top:10px">{lt}</div></div><div><h2 class="t-sub" style="margin-bottom:14px">{t}</h2><ul class="chg">{li}</ul></div></div>'
    page("/changelog", f"Changelog — {BRAND}", hero + sec("white", f'<div class="rows">{out}</div>'), active="/changelog", desc="What's new.")

# ---------------------------------------------------------------- LOGIN
def login():
    P = BRAND
    g = '<button class="btn-ghost" type="button" style="width:100%;justify-content:center">Continue with Google</button>'
    body = f'''<div class="login"><div class="l"><a class="logo" href="{L("/")}">{LOGO}<span>{P}</span></a>
<div><p class="eyebrow">Free · 10M tokens/month · No credit card</p><h1 class="t-sec m" style="margin-top:22px">Get<br>Started</h1></div><p class="eyebrow">{P}</p></div>
<div class="r"><div class="box"><div class="lt" role="tablist"><button type="button" data-p="create">Create Account</button><button type="button" data-p="signin">Sign In</button></div>
<div class="lp" data-p="create"><h2 class="t-sub">Create your account</h2><p class="lead" style="font-size:1rem;margin:10px 0 24px">Sign up with Google and your API key is ready instantly.</p>
<form class="form" onsubmit="return false"><label>Your name<input autocomplete="name"></label>{g}<div class="or">or sign up with email</div>
<label>Email address<input type="email" autocomplete="email"></label><label>Password<input type="password" autocomplete="new-password"></label><label>Confirm password<input type="password" autocomplete="new-password"></label>
<button class="btn" type="submit">Create Free Account →</button></form><p class="note">Already have an account? <a href="#" data-go="signin" style="text-decoration:underline">Sign in →</a></p></div>
<div class="lp" data-p="signin" hidden><h2 class="t-sub">Welcome back</h2><p class="lead" style="font-size:1rem;margin:10px 0 24px">Sign in to your {P} account.</p>
<form class="form" onsubmit="return false">{g}<div class="or">or sign in with email</div><label>Email address<input type="email" autocomplete="email"></label><label>Password<input type="password" autocomplete="current-password"></label>
<button class="btn" type="submit">Sign In →</button></form><p class="note">New here? <a href="#" data-go="create" style="text-decoration:underline">Create a free account →</a></p>
<p class="note"><b>Admin access</b> — Use your admin email and password above. The form above handles admin login too — just enter your credentials.</p></div></div></div></div>'''
    page("/login", f"Get Started — {P}", body, desc="Create your free account")

# ---------------------------------------------------------------- SECURITY
def security():
    P = BRAND
    hero = page_hero("Security & Privacy", "Built with hard floors, / not soft promises.", f"{P} processes data in-flight, stores nothing, and protects sensitive conversations at the architecture level — not the policy level.")
    dh = sec("white", f'<div class="reveal">{eyebrow("01","Data Handling")}<h2 class="t-sec m">Zero persistence.</h2></div><div class="grid2 mt reveal">' + feat_cells([
        ("No conversation storage","Conversations are processed entirely in memory. After the compress → forward pipeline completes, no message content is retained. No logs, no buffers, no backups."),
        ("API keys never stored in logs",f"Your LLM provider API key (x-llm-key) is forwarded to the upstream model and immediately discarded. It never touches our database. {P} keys are stored as SHA-256 hashes — not plaintext."),
        ("Semantic cache — anonymised","The semantic cache stores embedding vectors, not text. A cache hit returns a compressed context by similarity — the original conversation text is never stored."),
        ("Usage logs — metadata only","We log: timestamp, key ID, endpoint, tokens saved, domain, cache hit status. No message content, no user identifiers, no IP addresses beyond rate-limiting (discarded after 1 minute).")]) + "</div>")
    pz = sec("coral", f'''<div class="split"><div class="reveal">{eyebrow("02","Protected Zones")}<h2 class="t-sec m">Architectural, not configurable.</h2>
<div style="display:flex;gap:10px;margin-top:28px;flex-wrap:wrap"><span class="tag" style="background:var(--navy);color:#fff">Hard floors — cannot be disabled</span></div>
<div style="display:flex;gap:10px;margin-top:14px;flex-wrap:wrap"><span class="tag">Medical</span><span class="tag">Legal</span><span class="tag">Crisis</span></div>
<p class="lead">When DistilBERT classifies a conversation as medical, legal, or crisis — compression is disabled at the function call level. The check happens inside compressHistory() before any other processing. This cannot be overridden by API callers, admin keys, subscription tier, or configuration.</p></div>
<div class="reveal grid2" style="grid-template-columns:1fr">''' + feat_cells([("No monetization of protected zones","Protected conversations are not counted toward your token quota. We do not run ads, sell insights, or use protected conversation data for any purpose."),("Response header evidence","Every response includes x-cts-protected: true/false and x-cts-domain so you can verify the classification at the application level.")]) + "</div></div>")
    inf = sec("navy", f'<div class="reveal">{eyebrow("03","Infrastructure")}<h2 class="t-sec m">Where your data runs.</h2></div><div class="grid3 mt reveal">' + "".join(
        f'<div class="cell dk"><h3 class="t-card">{a}</h3><p>{b}</p></div>' for a, b in [
        ("Google Cloud Run","Serverless containers, auto-scaling, 4GiB memory, min-instances=1 for consistent latency. No shared state between instances."),
        ("GCP region: asia-south1","Default region is Hyderabad (asia-south1). Enterprise customers can request US-East, EU-West, or bring their own VPC."),
        ("TLS 1.3 everywhere","All traffic encrypted in transit via TLS 1.3. HSTS headers enforced. No HTTP fallback on any production endpoint."),
        ("Firebase Firestore","API key metadata stored in Firestore (hashed keys, quota counters, usage metadata). No conversation content ever reaches the database."),
        ("Rate limiting per key","Per-key rate limits enforced in memory per Cloud Run instance. DDoS protection via GCP Load Balancer. Burst capacity handled via Cloud Armor."),
        ("Dependency audit","Open source dependency manifest available on request. We run npm audit on every build. Critical CVEs block deployments.")]) + "</div>")
    rd = sec("teal", f'''<div class="split"><div class="reveal">{eyebrow("04","Responsible Disclosure")}<h2 class="t-sec m">Found a vulnerability?</h2>
<div style="margin-top:28px"><a class="btn" href="mailto:team@yudi.co.in">Report a vulnerability →</a></div></div>
<div class="reveal prose"><p>We take security reports seriously. Email <a href="mailto:team@yudi.co.in" style="text-decoration:underline">team@yudi.co.in</a> with a description of the issue and steps to reproduce. We'll acknowledge within 24 hours and work to resolve within 7 days for critical issues.</p>
<p>Please do not publicly disclose the vulnerability until we've had a chance to address it. We don't have a formal bug bounty program yet — but we'll acknowledge your contribution publicly if you'd like.</p></div></div>''')
    page("/security", f"Security — {P}", hero + dh + pz + inf + rd, active="/security", desc="Built with hard floors, not soft promises.")

# ---------------------------------------------------------------- ABOUT
def about():
    P = BRAND
    hero = page_hero("About", "Built in Hyderabad. / Thinking from first principles.", f"{P} is built by Yudi Labs — a small AI research team focused on making LLMs structurally better, not just faster.")
    org = sec("white", f'''<div class="split"><div class="reveal">{eyebrow("01","Origin")}<h2 class="t-sec m">Why we built this.</h2></div>
<div class="reveal prose"><p>Every AI product we built hit the same wall. By turn 10 of a conversation, you're sending thousands of tokens to the LLM — most of which is noise from earlier turns. The model's attention dilutes. Costs climb. Quality drops.</p>
<p>The existing solutions were either too broad (truncate everything after N tokens) or too opinionated (extract facts into a graph, then re-inject them). Neither approach preserved conversational meaning well. Neither knew when to leave a conversation alone.</p>
<p>{P} started from a simple question: what does the brain do here? Humans don't replay full conversation transcripts to recall context. They compress — keeping signal, discarding noise. The key insight is that compression is domain-specific. You compress a casual chat aggressively. You compress a legal document not at all.</p></div></div>''')
    mis = sec("navy", f'''<div class="split"><div class="reveal">{eyebrow("02","Mission")}<h2 class="t-sec m">What we're trying to do.</h2></div>
<div class="reveal prose"><p class="lead" style="margin-top:0">Make context management invisible infrastructure. The same way you don't think about TCP/IP when you send an email — you shouldn't have to think about context compression when you build an AI product.</p>
<p>The long-term goal: {P} becomes the default layer between applications and LLMs — the thing that makes AI applications cheaper to run, better in quality, and safer by default.</p></div></div>''')
    pr = sec("white", f'<div class="reveal">{eyebrow("03","Principles")}<h2 class="t-sec m">How we think.</h2></div><div class="grid2 mt reveal">' + feat_cells([
        ("First principles, not benchmarks","We start by asking what the brain does, then ask if that's what we should do. Benchmarks validate — they don't design."),
        ("Hard floors, not soft guardrails","Protected zones are architectural, not configurable. Some decisions should not be delegatable to end users or API callers."),
        ("Reproducibility is the claim","Every number we publish comes with a command you can run. If you can't verify it, we won't claim it."),
        ("Sparse, local, continual",f"Our broader research agenda at Yudi Labs. AI systems should be sparse in what they attend to, local in how they learn, and continual in how they improve. {P} is one expression of these principles.")]) + "</div>")
    ct = sec("coral", f'''<div class="reveal">{eyebrow("04","Contact")}<h2 class="t-sec m">Get in touch.</h2></div><div class="grid2 mt reveal">
<div class="cell"><h3 class="t-card">General</h3><p>Questions, feedback, or press inquiries: <a href="mailto:team@yudi.co.in" style="text-decoration:underline">team@yudi.co.in</a></p></div>
<div class="cell"><h3 class="t-card">Enterprise &amp; Partnerships</h3><p>Custom deployments, white-labeling, reseller partnerships: <a href="{L("/enterprise")}" style="text-decoration:underline">see the Enterprise page</a> or email us directly.</p></div>
<div class="cell"><h3 class="t-card">GitHub</h3><p>Open eval harness and issue tracker: <a href="https://github.com/ashy5454/echoregent" style="text-decoration:underline">github.com/ashy5454/echoregent</a></p></div>
<div class="cell"><h3 class="t-card">Location</h3><p>Yudi Labs, Hyderabad, India.</p></div></div>''')
    page("/about", f"About — {P}", hero + org + mis + pr + ct, active="/about", desc="Built in Hyderabad. Thinking from first principles.")
