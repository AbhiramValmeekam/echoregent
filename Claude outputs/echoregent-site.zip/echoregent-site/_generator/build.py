import shutil, os
import lib
from pages_a import home, product, cs, coding, agents
from pages_b import enterprise, research, docs, pricing, blog, changelog, login, security, about

if os.path.exists(lib.OUT): shutil.rmtree(lib.OUT)
os.makedirs(lib.OUT)
for f in (home, product, cs, coding, agents, enterprise, research, docs, pricing, blog, changelog, login, security, about): f()
shutil.copytree(os.path.join(os.path.dirname(__file__), "assets"), os.path.join(lib.OUT, "assets"))
print(sorted(os.listdir(lib.OUT)))
