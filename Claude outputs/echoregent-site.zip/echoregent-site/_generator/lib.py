import html, os, re

BRAND = "Prexi"           # on-site brand from the source website (verbatim). Change here to rebrand every page.
OUT = os.environ.get("OUT", "/home/claude/site_build/dist")

PAGES = {
 "/": "index.html", "/product": "product.html",
 "/solutions/customer-support": "solutions-customer-support.html",
 "/solutions/coding-assistants": "solutions-coding-assistants.html",
 "/solutions/ai-agents": "solutions-ai-agents.html",
 "/enterprise": "enterprise.html", "/research": "research.html", "/docs": "docs.html",
 "/pricing": "pricing.html", "/blog/": "blog.html", "/changelog": "changelog.html",
 "/login": "login.html", "/security": "security.html", "/about": "about.html",
}

def L(p):
    """map a source-site path (with optional #hash) to a local file link"""
    if p.startswith(("mailto:", "http", "#")): return p
    base, _, h = p.partition("#")
    f = PAGES.get(base, base)
    return f + ("#" + h if h else "")

def e(s): return html.escape(s, quote=False)
def br(s): return s.replace(" / ", "<br>")

LOGO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M3 21 12 3l9 18M7.5 14h9"/></svg>'

def eyebrow(num, label):
    return f'<div class="eb-row"><span class="n">{num}</span><span class="ln"></span><span class="lb">{e(label)}</span></div>'

def btn(text, href, kind="btn"):
    return f'<a class="{kind}" href="{L(href)}">{text}</a>'

def code(text, title="", raw=False):
    body = text if raw else e(text)
    return (f'<div class="code"><div class="bar"><span>{e(title)}</span><button type="button">Copy</button></div>'
            f'<pre><code>{body}</code></pre></div>')

def table(head, rows, hl=None, first_hl=False):
    h = "".join(f"<th>{e(c)}</th>" for c in head)
    r = ""
    for i, row in enumerate(rows):
        cls = ' class="hl"' if (hl is not None and i == hl) else ""
        r += f"<tr{cls}>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>"
    return f'<div class="tbl-wrap"><table><thead><tr>{h}</tr></thead><tbody>{r}</tbody></table></div>'

def sec(cls, inner, id="", extra=""):
    i = f' id="{id}"' if id else ""
    return f'<section class="sec {cls} {extra}"{i}><div class="wrap">{inner}</div></section>'

def checks(items): return '<ul class="checks">' + "".join(f"<li>{i}</li>" for i in items) + "</ul>"

def stats(items):
    return '<div class="stats reveal">' + "".join(
        f'<div><div class="stat-n">{a}</div><div class="eyebrow stat-l">{e(b)}</div></div>' for a, b in items) + "</div>"

NAV = [
 ("Product", [("Context Classifier","/product"),("History Compressor","/product#compress"),("Semantic Cache","/product#cache"),("Protected Zones","/product#protect"),("MCP Server","/product#mcp"),("OpenAI Proxy","/product#proxy")]),
 ("Solutions", [("Customer Support","/solutions/customer-support"),("Coding Assistants","/solutions/coding-assistants"),("AI Agents","/solutions/ai-agents"),("Enterprise","/enterprise")]),
]
LINKS = [("Research","/research"),("Docs","/docs"),("Pricing","/pricing"),("Blog","/blog/"),("Changelog","/changelog")]

def header(active):
    n = ""
    for t, items in NAV:
        n += f'<div class="dd"><button type="button" aria-haspopup="true">{t} ▾</button><div class="dd-menu">' + "".join(f'<a href="{L(h)}">{l}</a>' for l, h in items) + "</div></div>"
    for l, h in LINKS:
        cur = ' aria-current="page"' if h == active else ""
        n += f'<a href="{L(h)}"{cur}>{l}</a>'
    dr = ""
    for t, items in NAV:
        dr += f"<h4>{t}</h4>" + "".join(f'<a href="{L(h)}">{l}</a>' for l, h in items)
    dr += "<h4>More</h4>" + "".join(f'<a href="{L(h)}">{l}</a>' for l, h in LINKS)
    dr += f'<a class="btn-coral btn" style="color:#0B1F3C;background:#FC7A5C" href="{L("/pricing#get-key")}">Get API Key</a>'
    return (f'<header class="hdr"><div class="wrap"><a class="logo" href="{L("/")}">{LOGO}<span>{BRAND}</span></a>'
            f'<nav class="nav" aria-label="Primary">{n}</nav>'
            f'<div class="hdr-cta"><a class="btn-ghost" href="{L("/login")}">Sign In</a><a class="btn-ghost" href="{L("/enterprise")}">Enterprise</a><a class="btn" href="{L("/pricing#get-key")}">Get API Key</a></div>'
            f'<button class="menu-btn" type="button" aria-expanded="false">MENU</button></div></header><div class="drawer">{dr}</div>')

def footer():
    col = lambda t, items: f"<div><h6>{t}</h6><ul>" + "".join(f'<li><a href="{L(h)}">{l}</a></li>' for l, h in items) + "</ul></div>"
    return (f'<footer class="ftr"><div class="wrap"><div class="top"><div><div class="bn">{BRAND}</div>'
        f'<p class="d">The context management layer that gives LLMs what remains. Built by Yudi Labs, Hyderabad.</p></div>'
        + col("Product", [("Overview","/product"),("Classifier","/product#classify"),("Compressor","/product#compress"),("Cache","/product#cache"),("Protected Zones","/product#protect"),("MCP Server","/product#mcp")])
        + col("Solutions", [("Customer Support","/solutions/customer-support"),("Coding Assistants","/solutions/coding-assistants"),("AI Agents","/solutions/ai-agents"),("Enterprise","/enterprise")])
        + col("Resources", [("Research","/research"),("Documentation","/docs"),("Blog","/blog/"),("Changelog","/changelog"),("Security","/security"),("GitHub ↗","https://github.com/ashy5454/echoregent")])
        + col("Company", [("About","/about"),("Enterprise","/enterprise"),("Security","/security"),("Contact","mailto:team@yudi.co.in")])
        + f'</div><div class="bot"><span>© 2026 {BRAND} · A product by Yudi Labs, Hyderabad, India</span>'
        f'<nav><a href="{L("/security")}">Privacy</a><a href="{L("/security")}">Terms</a><a href="{L("/security")}">Security</a><a href="mailto:team@yudi.co.in">team@yudi.co.in</a></nav></div></div></footer>')

def page(path, title, body, active=None, desc="", og=None, bare=False):
    fn = PAGES[path]
    head = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(title)}</title><meta name="description" content="{html.escape(desc)}">
<meta property="og:title" content="{html.escape(og or title)}"><meta property="og:description" content="{html.escape(desc)}">
<meta name="theme-color" content="#0B1F3C">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Space+Grotesk:wght@400;500;700&family=Inter:wght@300;400;500&family=JetBrains+Mono:wght@400;600&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/styles.css"></head><body>
<a class="skip" href="#main">Skip to content</a>'''
    out = head + header(active or path) + f'<main id="main">{body}</main>' + footer() + '<script src="assets/site.js"></script></body></html>'
    os.makedirs(OUT, exist_ok=True)
    open(os.path.join(OUT, fn), "w", encoding="utf-8").write(out)

def page_hero(label, title, sub="", actions="", cls="grid"):
    return sec(cls + " pad-t page-hero",
        f'<div class="reveal">{eyebrow("", label)}<h1 class="t-sec">{br(title)}</h1>' + (f'<p class="lead">{sub}</p>' if sub else "") +
        (f'<div class="actions">{actions}</div>' if actions else "") + "</div>")
